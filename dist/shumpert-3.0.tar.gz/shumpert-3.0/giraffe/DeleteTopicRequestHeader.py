#!/usr/bin/python

import json

class DeleteTopicRequestHeader:

  def __init__(self, topic):
    self.topic = topic

