#!/usr/bin/python
# -*- coding: UTF-8 -*-

import re
import sys
import socket #for sockets

#字符串编码统一为utf8
imp.reload(sys)

